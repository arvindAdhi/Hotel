package com.Oyo.HotelSideManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelSideManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
