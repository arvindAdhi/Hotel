package com.Oyo.HotelSideManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelSideManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelSideManagementApplication.class, args);
	}

}
